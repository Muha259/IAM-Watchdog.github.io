document.addEventListener("DOMContentLoaded", function() {
    // Smooth scrolling
    document.querySelectorAll('nav a').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            document.getElementById(targetId).scrollIntoView({ behavior: 'smooth' });
        });
    });

    // Fade-in effect on scroll
    const sections = document.querySelectorAll("section");
    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add("fade-in");
            }
        });
    }, { threshold: 0.2 });

    sections.forEach(section => {
        section.classList.add("hidden");
        observer.observe(section);
    });

    // Typing effect
    const textElement = document.querySelector("#typing-text");
    const text = "Cybersecurity Enthusiast | Cloud Security Defender";
    let index = 0;

    function typeText() {
        if (index < text.length) {
            textElement.innerHTML += text[index];
            index++;
            setTimeout(typeText, 100);
        }
    }
    typeText();
});
